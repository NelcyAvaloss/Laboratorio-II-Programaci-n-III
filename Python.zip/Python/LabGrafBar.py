import pandas as pand
import matplotlib.pyplot as mtp

SpotifySongMost =pand.read_csv( r"C:\Users\nelcy\Downloads\Popular_Spotify_Songs.csv",encoding='latin1')

#print(SpotifySongMost)

# Lo que haremos a continuacion es filtrar el top 10 de canciones con mas escuchas (stream) de spotify

SpotifySong = SpotifySongMost[['track_name', 'streams', 'artist(s)_name']].sort_values('streams', ascending=False).head(5)

mtp.figure(figsize=(8, 6))

mtp.bar(SpotifySong['track_name'], SpotifySong['streams'], color='purple')

mtp.xticks(rotation=90, ha='right')
mtp.xlabel('Canciones')
mtp.ylabel('Streams')
mtp.title('Canciones más escuchadas de Spotify')
mtp.tight_layout()
mtp.show()


