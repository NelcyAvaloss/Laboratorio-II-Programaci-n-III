import pandas as pd
import matplotlib.pyplot as plt


# Cargamos el conjunto de datos
medallas_olimpicas = pd.read_csv(r"C:\Users\nelcy\Downloads\MedallasOlimpicas.csv")

# Ordenamos los datos en orden descendente y seleccionar los 10 mejores países por medallas de oro
seleccion_medallas = medallas_olimpicas[['country', 'country_code', 'gold']].sort_values('gold', ascending=False).head(10)

# Renombrar las columnas para que sean más intuitivas en el contexto del análisis
seleccion_medallas.rename(columns={'country': 'país', 'country_code': 'código_país', 'gold': 'medallas_oro'}, inplace=True)

# Concatenar el nombre del país con su código para las etiquetas
seleccion_medallas['label'] = seleccion_medallas['país'] + ' (' + seleccion_medallas['código_país'] + ')'

# Configuramos nuestros datos
plt.figure(figsize=(12, 8))
plt.plot(seleccion_medallas['label'], seleccion_medallas['medallas_oro'], marker='s', linestyle='-', color='black')

# Agregamos etiquetas de datos
for i, value in enumerate(seleccion_medallas['medallas_oro']):
    plt.text(i, value, str(value), ha='center', va='bottom', fontsize=9, color='black')

#  Y por ultimo agregamos la configuración de la gráfica
plt.xticks(rotation=45, ha='right')
plt.xlabel('País (Código)')
plt.ylabel('Medallas de Oro')
plt.title("Top 10 Países con Más Medallas de Oro en las Olimpiadas")
plt.tight_layout()
plt.show()