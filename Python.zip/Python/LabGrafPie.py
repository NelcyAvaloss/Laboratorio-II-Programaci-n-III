import pandas as pand
import matplotlib.pyplot as mtp

# Cargamos el dataset desde el archivo CSV
NetflixRating = pand.read_csv(r"C:\Users\nelcy\Downloads\imdb.csv")

# Verificamos las primeras filas del dataset para asegurarnos de las columnas
print(NetflixRating.head(10))

# Agrupamos por 'program_name' y calculamos el promedio de 'rating' (ajusta los nombres según tu CSV)
NetfliXMostRating = NetflixRating.groupby(['lister-item-header'])['rating'].mean().sort_values(ascending=False).head(10)

# Configuramos la gráfica de pastel
mtp.figure(figsize=(8, 8))
mtp.pie(NetfliXMostRating, labels=NetfliXMostRating.index, autopct='%1.1f%%', startangle=140, 
        colors=['blue', 'purple', 'green', 'gray', 'pink', 'orange', 'red', 'yellow', 'cyan', 'brown'])
mtp.title('Distribución de los 10 programas más valorados en Netflix')
mtp.tight_layout()
mtp.show()
